import React from 'react'
import { useState } from 'react'
import {Table} from './Table'

export const MeTodo = () => {

    const [state, setState] = useState({
        Name:'Aadi',
        Age:'21',
        Data:[]
    })

    const changeHandler = (e) => {
        console.log("a");
        setState({...state,[e.target.name]:e.target.value})
    }

    const clickHandler = (e) =>{
        e.preventDefault()
        const FinalData = {
            Name: state.Name,
            Age: state.Age
        }
        setState({
            Data:[FinalData]
        })
    }

    console.log("a",state);
    console.log("b",state.Data);

    return (
        <div>
            <h1> Hey! </h1>
            <label> Name: </label>
            <input type="text" value={state.Name} name="Name" onChange={(e)=>{changeHandler(e)}}/> <br/><br/>
            <label> Age: </label>
            <input type="text" value={state.Age} name="Age" onChange={(e)=>{changeHandler(e)}}/> <br/><br/>
            <button onClick={(e)=>{clickHandler(e)}}> INPUT </button>
            <Table data={state.Data}/>
        </div>
    )
}
