import React from 'react'

export const Header = () => {
    return (
        <div>
            <h1> List </h1>
        </div>
    )
}
