import React from 'react'

export const Table = (props) => {
    return (
        <div>
            {props.data.map(xx=>{
                console.log(xx)
            })}
        </div>
    )
}
